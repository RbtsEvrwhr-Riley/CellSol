#pragma once

// The Heltec WiFi LoRa 32 V3 has an SX1262. Sandeep Mistry's LoRa library
// speaks to SX127x chips, so this small adapter supplies only the CellSol
// operations via RadioLib. Install "RadioLib" from Arduino Library Manager.
#include <RadioLib.h>

class CellSolRadioV3
{
public:
  CellSolRadioV3()
    : radio(new Module(RADIO_NSS, RADIO_DIO_1, RADIO_RESET, RADIO_BUSY)) {}

  void setSpreadingFactor(int sf) { spreadingFactor = sf; }
  void setSignalBandwidth(long hz) { bandwidth = hz / 1000.0f; }
  void setTxPower(int dbm)
  {
    txPower = dbm;
    if (radioActive)
      radio.setOutputPower(dbm);
  }

  bool begin(long hz)
  {
    SPI.begin(SCK, MISO, MOSI, SS);
    radio.tcxoVoltage = RadioLibTCXOVoltage_t::Voltage1V8;
    ConfigLoRa_t config;
    config.frequency = hz / 1000000.0f;
    config.bandwidth = bandwidth;
    config.spreadingFactor = spreadingFactor;
    config.codingRate = 5; // 4/5, same as Sandeep Mistry LoRa defaults
    config.syncWord = 0x12;
    config.power = txPower;
    config.preambleLength = 8;
    int16_t result = radio.begin(config);
    if (result != RADIOLIB_ERR_NONE)
      return false;

    // The older CellSol SX127x firmware uses explicit headers and no CRC.
    // These two details must agree for mixed V2/V3 networks.
    if (radio.setCRC(0) != RADIOLIB_ERR_NONE)
      return false;
    radio.setDio1Action(onReceive);
    received = false;
    radioActive = (radio.startReceive() == RADIOLIB_ERR_NONE);
    return radioActive;
  }

  void end()
  {
    if (radioActive)
    {
      radio.clearDio1Action();
      radio.sleep();
    }
    radioActive = false;
    received = false;
    rxLength = 0;
    rxOffset = 0;
  }

  int beginPacket()
  {
    txBuffer = "";
    return 1;
  }

  size_t print(const String &s)
  {
    if (txBuffer.length() + s.length() > 255)
      return 0;
    txBuffer += s;
    return s.length();
  }

  int endPacket()
  {
    received = false;
    const int16_t result = radio.transmit((const uint8_t *)txBuffer.c_str(),
                                          txBuffer.length());
    radio.startReceive();
    return result == RADIOLIB_ERR_NONE ? 1 : 0;
  }

  int parsePacket()
  {
    if (!received)
      return 0;
    received = false;
    const size_t length = radio.getPacketLength();
    if (length == 0 || length > sizeof(rxBuffer))
    {
      radio.startReceive();
      return 0;
    }
    const int16_t result = radio.readData(rxBuffer, length);
    lastRssi = (int)radio.getRSSI();
    rxLength = result == RADIOLIB_ERR_NONE ? length : 0;
    rxOffset = 0;
    radio.startReceive();
    return rxLength;
  }

  int packetRssi() const { return lastRssi; }
  int available() const { return rxLength - rxOffset; }

  size_t readBytes(char *destination, size_t maxLength)
  {
    size_t count = min(maxLength, (size_t)available());
    memcpy(destination, rxBuffer + rxOffset, count);
    rxOffset += count;
    return count;
  }

private:
  static void IRAM_ATTR onReceive() { received = true; }

  SX1262 radio;
  int spreadingFactor = 9;
  float bandwidth = 62.5f;
  int txPower = 20;
  int lastRssi = -120;
  bool radioActive = false;
  String txBuffer;
  uint8_t rxBuffer[255] = {};
  size_t rxLength = 0;
  size_t rxOffset = 0;
  static volatile bool received;
};

volatile bool CellSolRadioV3::received = false;
CellSolRadioV3 LoRa;
