# CellSol ESP32 settings page (V2 / Arduino-ESP32 3.x)

This build includes a persistent, unlisted settings page. It is not linked
from the normal chat interface.

1. Flash the ESP32 firmware, using `LORA32V2` in `config.h` for the Heltec V2.
2. Connect to the pylon's WiFi AP, or use its upstream IP if already in STA mode.
3. Open `http://<pylon-ip>/derpderp`. For example,
   `http://192.168.2.118/derpderp` when the pylon's IP is `192.168.2.118`.
4. Edit the settings, then press **Save settings and restart**.
5. Reconnect to the new network after the pylon restarts.

Change `SETTINGS_PAGE_PATH` in `config.h` to rename the route. This is an
unadvertised route, **not an authentication scheme**. Anyone with network
access and the path can change settings. Upstream WiFi passwords are submitted
via HTTP POST, not in the query string; HTTP is nevertheless unencrypted.

## Settings stored in ESP32 NVS

- Optional pylon node ID override. Enter any four hexadecimal digits, such as
  `ba5e`; the last digit is automatically masked to `0`, making the base ID
  `ba50`. The remaining low-nibble values belong to WiFi, Bluetooth, and
  serial client tags. Enter `0000` (or leave the field blank) to generate the
  ID automatically. Manually selected IDs bypass battery-derived ID noise.
- Connection mode: WiFi AP, Bluetooth only, AP+Bluetooth, upstream WiFi
  client+Bluetooth, or hybrid AP+client+Bluetooth.
- Local WiFi AP third IPv4 octet (0-254), independent of the node ID. Leaving
  it blank uses the hardware-derived octet. This is separate from the
  editable upstream client IP, gateway, and subnet.
- AP/Bluetooth name prefix and WiFi transmit power (0-11).
- Upstream WiFi SSID and password. The password field is blank when editing;
  blank preserves the existing password. A separate checkbox clears it.
- DHCP or static client IP, gateway, and subnet.
- IRC enable/disable, server, port, channel, nickname prefix, forwarding
  prefix, per-pylon tagged channel option, and forwarding from other CellSol
  IRC pylons without requiring their messages to have the text prefix.

`config.h` values are the initial defaults on an unconfigured device. Once
settings are saved, NVS takes precedence until erased. Reflashing firmware
without erasing NVS does not clear these settings.

When an ID change is saved, the ESP32 records the old ID in NVS and restarts.
Once the radio is initialized, it transmits the Arduino-compatible
`oldID:>>>newID` packet over LoRa, then clears the pending notice. This also
ensures that restoring an automatically generated, battery-dependent ID
announces the ID actually chosen after reboot. If LoRa fails to initialize,
the pending notice remains stored for a later successful startup.
All derived client tags use the new base ID after restart. The local AP
address (`192.168.<AP octet>.1`) is configured separately: changing only the
node ID does not change the AP subnet or name. Upgrading a v0.33b device with
an existing manual ID retains its previous local AP third octet. Future ID
changes leave that value alone. IDs starting with `ff` are allowed since
the node ID no longer determines the AP subnet.

## Recovering access

- While booting in **standard AP mode**, hold PROG to select Bluetooth,
  preserving the original behavior.
- While booting in **any other saved mode**, hold PROG to run a temporary
  WiFi AP instead, without modifying NVS. Open its `/derpderp` page to fix
  settings, save, and reboot.
- If an upstream WiFi connection fails for 12 seconds, a temporary AP starts
  automatically. It uses the current configured AP name prefix.

Battery thresholds, deep sleep, LoRa band and on-air parameters, and hardware
pins remain in `config.h`/`pinout.h`. They are deliberately not runtime
configurable because a mismatched LoRa frequency/SF/BW can isolate a pylon from
the rest of a CellSol deployment.

The settings are applied after reboot, not in the middle of a transmission.
Runtime modes have been wired in for Heltec V2. Heltec V3 remains untested.
