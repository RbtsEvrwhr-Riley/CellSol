// hardware platform types; pick one and only one. Default is LORA32 V2. If yours is not in here, you'll have to adjust stuff manually. They will override some settings (for example, selecting TTGO will turn off the display since there isn't one)
//#define LORA32V3 // Heltec WiFi LoRa 32 V3 (ESP32-S3 + SX1262). Requires RadioLib and HardwareBLESerial/ArduinoBLE.
#define LORA32V2 // Heltec LORA32 V2 (White board). More progmem, screen, no gps, battery ADC. This is the default and development will mostly happen on this board.  Start developing here if you have the esp32 with more progmem
//#define LORA32V1 // Heltec clone (Black board) (TTGO LoRa OLed V1). Less progmem, screen, no gps, no battery ADC. Start developing here if you have the esp32 with less progmem
//#define TBEAM // TTGO T-Beam (Black board with gps). Less progmem, no screen, gps, no battery ADC.
// If none of these are defined you'll end up with a minimal feature set. To change these settings, use pinout.h

// Physical radio band. Choosing the wrong range WILL DAMAGE YOUR RADIO MODULE. Currently set up to stay a little away from the main LoRa and LoRaWAN radio ranges out of politeness.
//4331E5 for worldwide (restrictions apply)

//8661E5 for Europe
//9151E5 for North America
//4331E5 for Asia
#define BAND 9151E5

// On-air compatibility: in 0.32 the SF/BW setters ran BEFORE LoRa.begin(),
// which hardware-reset the SX127x. Existing pylons therefore normally use
// the radio reset defaults (SF7, 125 kHz), not the commented SF9/62.5 kHz.
// Change BOTH values on every node together if you want the intended slower
// settings; otherwise a new pylon will not hear older ones.
#define CELLSOL_LORA_SF 7
#define CELLSOL_LORA_BW_HZ 125000L
// To use the originally intended longer-range mode, change these to 9 and
// 62500L respectively on every pylon in the network.

// Initial defaults for devices with no saved NVS settings. Once configured,
// choose WiFi / Bluetooth / upstream / IRC options from the web page instead.
// Physical radio hardware and power-safety settings remain compile-time.


// The first mode saves power but makes the AP invisible 45 seconds out of every minute.
//#define MODEFLIP 15000 // minimum suggested: 12000. powershare mode operates the pylon on full AP for this many milliseconds every minute, and as a repeater the rest of the time. It is exclusive with the other options. The mode flip will pause if there are clients connected or if the battery is full enough.

// Legacy mode macros (optional initial defaults only). These modes draw
// significantly more power than standard AP operation.
//#define BT_ENABLE_FOR_AP
//#define WIFI_IS_CLIENT
//#define WIFI_IS_HYBRID

//#define REPEATER_ONLY // Uncomment this to bypass everything else and runs as repeater (and serial) only. useful if we are out of arduinos. not useful otherwise.

#if (defined(LORA32V1) + defined(LORA32V2) + defined(LORA32V3) + defined(TBEAM)) != 1
#error "Select exactly one CellSol board in config.h"
#endif

//#define NODISPLAY // display is either absent or should be kept off at all times. Saves some power, naturally.

#define COMMUNITY_MEMORY_SIZE 50 // old lines to keep (other than the last 10)

#define SEND_TWICE // if defined, allow sending a packet twice after a pseudorandom delay, in case the first one got lost
#define RSSI_TRE_LO -120 // if sendtwice is defined, below this (for the last 4 received packets), turn on sendtwice
#define RSSI_TRE_HI -100 // if sendtwice is defined, above this (for the last 4 received packets), turn off sendtwice
#define REBROADCAST_DISASTER_RADIO_PACKETS // if this is defined, we will rebroadcast Disaster Radio packets, for interoperability.
//#define DISPLAY_DISASTER_RADIO_PACKETS // if this is defined, we will display Disaster Radio packets, for interoperability.

/**
   WEBPAGE CONFIG
*/
#define TUTORIALSTRINGS // On first activation after a poweroff/reset, should we display a mini help on the screen?

#define PROVIDE_APK // make bluetooth terminal apk available?
#define PROVIDE_CAT_PICTURE // load cat picture as an example of embedded file?
#define PROVIDE_SOURCE_CODE // embed source zip in source for the glory of recursion?
#define SERVE_FAQ_PAGE  // if undefined, do not add help page
#define REFRESH_CHAT_EVERY 3 // seconds

#define REQUIRE_TAG_FOR_REBROADCAST // if defined, require xxxx: tag for rebroadcast.
//#define REQUIRE_TAG_FOR_REBROADCAST_STRICT // on top of that, the first four characters must be hex digits.
#define BAD_CHARACTERS_MAX_DIVIDER 10 // 1/x of bad characters before we discard the string
//#define SHOW_RSSI // if enabled, show RSSI for wireless packets coming in.

#define TAG_END_SYMBOL ':'

/**
   NETWORK CONFIGURATION
*/
// Unlisted local configuration URL: http://<pylon-ip>/derpderp
// Change this string to change the path. It is NOT authentication.
#define SETTINGS_PAGE_PATH "derpderp"

// Settings on the web page are persisted in ESP32 NVS. The values below are
// initial defaults for devices whose NVS has not yet been configured.
//This is the root name for the AP. It will be used when in AP mode.
#define SSIDROOT "CellSol "

// these only affect client and hybrid modes. The local AP uses 192.168.x.1,
// with x set independently on the settings page or derived from hardware.
// the upstream router will have to either open port 80 to this, or do a redirect.
#define CLIENT_IP_ADDR 192,168,2,119 // client IP address for client or hybrid mode. needs commas instead of periods
#define GATEWAY_IP_ADDR 192,168,2,1 // router IP address for client or hybrid mode. needs commas instead of periods
#define GATEWAY_SUBNET 255,255,255,0 // subnet mask for client or hybrid mode. needs commas instead of periods
#define WIFI_UPSTREAM_AP "RobotsEverywhere_24" // SSID of the router we're trying to connect to. 
#define WIFI_UPSTREAM_PWD "derpderp"// password for the router we're trying to connect to. Use "" for none/open.

#define DHCP // DHCP on if defined; will ignore IP address setting fields above in that case.

// irc relay stuff (only used if wifi is client or hybrid)

#define IRC_SERVER   "irc.rizon.net" // initial server; enable/disable IRC on the settings page
#define IRC_PORT     6667
#define IRC_NICK_ROOT "CellSol" // will add hextag
#define IRC_CHAN_ROOT "CellSol" // will add hextag if the line below is uncommented
//#define IRC_CHAN_HEXTAG
#define FWD_PREFIX "~~" // if there's a prefix, forward it to the radio stuff, otherwise don't.
#define ALLOW_PYLON_FORWARD // if this is defined, other cellsol pylons are exempt from FWD_PREFIX, and will format formward message in a more compact way.
#define IRC_FAILED_TRE 9 // if more than this many fails, stop trying
#define IRC_TOPIC "CellSol relay channel! Start your message with " FWD_PREFIX " to forward to radio. Example: " FWD_PREFIX "Please report!" // Edit this to fit, specifically if you remove FWD_PREFIX.
#define USE_BATTERY_NOISE_FOR_ID // if undefined, same id across power cycles. if not, use battery level to get a bit of noise in the ID (mostly to avoid creepy people hashing it to figure out where you are).
#define DO_NOT_LOG_SYSTEM_PACKETS // Don't display system packets to avoid spamming out human messages (example: UTC fix)

//#define DEBUG_OPTION_PAGE // if you don't know what this is, don't use it.

// this affects wifi range. obviously it will affect power consumption. it does not affect lora range. for line powered stuff, it'll be turned up to 11. For default, keep it commented out.
#define WIFI_POWER_LEVEL 4 // 0 to 11, higher = stronger. lora power level is fixed at 19/20 because 20/20 can mess up some radios.

// Repeat sending the last message until you hear it back. WARNING: high send frequency devices may have issues with this feature.
// #define REPEAT_UNTIL_ACK
// #define REPEAT_DELAY 5000 // delay in ms

/**
   BATTERY & SLEEP CONFIGURATION
*/

// more timing stuff
#define SLEEP_TIME 60 // this is in seconds - how long to sleep before waking up and checking power level again? NOT ACCURATE.
#define DISPLAY_INTERVAL 3000 // Milliseconds to keep the OLED on after a button press in AP/BT mode. Upstream WiFi modes keep it on.

// battery stuff
#define MODEFLIP_BATTERY_FULL 1304 // if modeflip, battery level above this will leave the module running on full. Useful if we are getting good sunlight and the battery is full anyway.
#define MODEFLIP_BUTTON // user button gets you back into high power mode

#define LPLOOP_BLINK 10000 // eversoly this many cycles (not milliseconds!), blink the led
#define ADC_INTERVAL 5000 // In milliseconds, how often to read the battery level? NOT ACCURATE.
#define FULL_BATT 1450 // unused but a good reference. more than this = there probably is no battery
#define BATT_HIGH_ENOUGH_FOR_FULL_POWER 1200 // above this, allow wifi/bt
#define BATT_TOO_LOW_FOR_ANYTHING 1065 // below this, don't try to turn on, go back to sleep and wait for better times
#define BATT_HYSTERESIS_POWER 15 // hysteresis between power state changes
#define POWER_STATE_CHANGE_ANNOUNCE false //  should the module announce it when it's coming online or going offline? (probably only for debugging)


/**
   DON'T TOUCH THESE, THEY ARE AUTOMATED
*/
// These compile-time mode macros now select only the DEFAULT operating mode.
// Once set from the web page, the saved NVS mode takes precedence.
#ifdef WIFI_IS_HYBRID
#ifndef WIFI_IS_CLIENT
#define WIFI_IS_CLIENT
#endif
#endif
#define RECONNECT_EVERY 60000UL
#define PYLONTYPE "AP)" // legacy display fallback; runtime uses activeMode

/**
   FURTHER AUTOMATED STUFF
*/
#ifdef REPEATER_ONLY
#define LPLOOP_BLINK 5000 // every this many cycles (not milliseconds!), blink the led
#define ADC_INTERVAL 10000 // In milliseconds, how often to read the battery level? NOT ACCURATE.
#define FULL_BATT 1450 // unused but a good reference. more than this = there probably is no battery
#define BATT_HIGH_ENOUGH_FOR_FULL_POWER 2000 // above this, allow wifi/bt
#define BATT_TOO_LOW_FOR_ANYTHING 1065 // below this, don't try to turn on, go back to sleep and wait for better times
#define BATT_HYSTERESIS_POWER 15 // hysteresis between power state changes
#define POWER_STATE_CHANGE_ANNOUNCE false //  should the module announce it when it's coming online or going offline? (probably only for debugging)
#define REFRESH_CHAT_EVERY 42 // doesn't really matter since it neveer gets called
#define PYLONTYPE "RPT)"// identifier for how we are running
#undef TUTORIALSTRINGS
#endif
// Keep IRC code available even in AP-only builds: the settings page can later
// enable an upstream WiFi/IRC gateway without reflashing.
